## My Personal Portfolio WebSite


Personal portfolio website made with Django framework in the backend, and with CSS, JS, and Bootstrap for the frontend. It is a dynamic site so that you can control the content of the site through the admin area.

<a align="center" href="https://abdelaali.tech/">
  <img align="center" src="https://img.shields.io/badge/View%20The%20Portfolio-Click%20me-blue" alt="center">
</a>

### Screenshots from the Portfolio:

#### Home Page:
<img aline="center" src="https://i.imgur.com/PgpXXLb.png" alt="secreenshot">

#### Education & Experiences Sections:
<img aline="center" src="https://i.imgur.com/bADD89k.png" alt="secreenshot">


#### Competences Section:
<img aline="center" src="https://i.imgur.com/7At1pqG.png" alt="secreenshot">


#### Projects Section (Slider Show):
<img aline="center" src="https://i.imgur.com/1S57RqD.png" alt="secreenshot">

#### About & Contact Me Sections:
<img aline="center" src="https://i.imgur.com/djYOST6.png" alt="secreenshot">
